package com.utez.fintree.integradora_final;

import com.utez.fintree.integradora_final.db.ConexionDB;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        // Cargamos nuestra nueva vista "LoginView.fxml"
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("LoginView.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 900, 600);
        stage.setTitle("QuanTree - Iniciar Sesión");
        stage.setScene(scene);
        stage.show();
    }

// En HelloApplication.java

    public static void main(String[] args) {
        // Llamamos a nuestro método para crear las tablas antes de lanzar la UI
        ConexionDB.inicializarDB();
        launch();
    }
}
/**
 * =================================================================================================
 * ANÁLISIS TÉCNICO DETALLADO DEL GASTOSCONTROLLER
 * =================================================================================================
 * * Este controlador es responsable de orquestar la vista principal de la sección de "Gastos".
 * Su lógica se puede descomponer en tres responsabilidades fundamentales:
 * 1. Vinculación de Datos (Data Binding) con el modelo centralizado.
 * 2. Renderización Personalizada de Componentes de la Interfaz (Custom UI Rendering).
 * 3. Manejo de Eventos y Navegación (Event Handling & Navigation).
 *
 * -------------------------------------------------------------------------------------------------
 * 1. VINCULACIÓN DE DATOS: EL GESTOR DE DATOS Y LA LISTA OBSERVABLE
 * -------------------------------------------------------------------------------------------------
 * La inicialización del controlador comienza obteniendo los datos de la aplicación.
 * * `ObservableList<Gasto> gastos = GestorDatos.getInstance().getGastos();`
 * * Esta línea es crucial por dos razones principales:
 * * a) PATRÓN SINGLETON (`GestorDatos.getInstance()`): Se utiliza el patrón de diseño Singleton para el `GestorDatos`.
 * Esto garantiza que exista una única instancia de `GestorDatos` a lo largo de todo el ciclo de vida de la
 * aplicación. El resultado es un "único punto de verdad" (Single Source of Truth) para el estado de los datos.
 * Cualquier modificación realizada a los datos (añadir, editar, eliminar) desde cualquier pantalla se reflejará
 * en todas las demás, evitando inconsistencias y la necesidad de pasar listas de datos manualmente entre controladores.
 * * b) LISTA OBSERVABLE (`ObservableList`): La lista devuelta no es un `ArrayList` estándar, sino una `ObservableList`
 * de JavaFX. Esta estructura de datos emite notificaciones cuando su contenido cambia. Al vincular esta lista a un
 * componente de la UI como un `ListView` (`listaGastos.setItems(gastos)`), el `ListView` se suscribe a estas
 * notificaciones. Consecuentemente, cualquier cambio en la lista (ej. `GestorDatos.getInstance().agregarGasto(...)`)
 * provoca una actualización automática de la interfaz gráfica sin necesidad de invocar métodos de refresco manuales.
 * Esto implementa un paradigma de programación reactiva.
 *
 * -------------------------------------------------------------------------------------------------
 * 2. RENDERIZACIÓN PERSONALIZADA: LA FÁBRICA DE CELDAS (`setCellFactory`)
 * -------------------------------------------------------------------------------------------------
 * Por defecto, un `ListView` simplemente invoca el método `toString()` del objeto para representarlo. Para lograr una
 * UI más compleja que incluya texto formateado y botones interactivos en cada fila, es imperativo sobreescribir
 * el comportamiento de renderizado de las celdas.
 * * `listaGastos.setCellFactory(...)`
 * * Este método establece una "fábrica" que produce celdas (`ListCell`) para la lista. Se le pasa una implementación
 * de la interfaz funcional `Callback`. El método `call()` del Callback debe devolver una nueva instancia de `ListCell`.
 * * Dentro de esta fábrica, se define una clase anónima que hereda de `ListCell<Gasto>`. Sus componentes clave son:
 * * a) CONSTRUCCIÓN DE LA UI DE LA CELDA: Se crean de forma programática los componentes de la UI para cada fila
 * (`HBox`, `Text`, `Pane`, `Button`). El uso de un `Pane` con `HBox.setHgrow(pane, Priority.ALWAYS)` es una técnica
 * de layout para crear un "resorte" flexible que empuja al botón "Editar" hasta el extremo derecho de la celda.
 * * b) EL MÉTODO `updateItem(Gasto item, boolean empty)`: Este es el núcleo del renderizado. JavaFX lo invoca
 * cada vez que una celda necesita ser dibujada o reutilizada (por ejemplo, al hacer scroll).
 * - La condición `if (empty || item == null)` es vital para limpiar las celdas que quedan vacías o que son
 * recicladas por el `ListView`, previniendo así la aparición de datos "fantasma".
 * - En el `else`, se actualiza el contenido de los nodos (`text.setText(...)`) y se asigna el `HBox` como el
 * gráfico de la celda (`setGraphic(hbox)`), haciéndolo visible.
 *
 * -------------------------------------------------------------------------------------------------
 * 3. MANEJO DE EVENTOS Y NAVEGACIÓN
 * -------------------------------------------------------------------------------------------------
 * a) EVENTO DEL BOTÓN "EDITAR": El `setOnAction` para el botón "Editar" se define dentro de la `ListCell`. Esto es
 * significativo porque cada botón está intrínsecamente ligado a la celda que lo contiene.
 * - `Gasto gastoSeleccionado = getItem();` : Dentro del ámbito de la `ListCell`, el método `getItem()` devuelve
 * el objeto `Gasto` específico para esa fila. Esto permite que el botón sepa exactamente qué entidad debe modificar.
 * - `abrirPantallaDeEdicion(gastoSeleccionado, event);`: Se invoca un método helper para encapsular la lógica de navegación.
 * * b) PASO DE DATOS ENTRE CONTROLADORES (`abrirPantallaDeEdicion`): Este método demuestra una técnica fundamental
 * para la comunicación entre controladores.
 * - `FXMLLoader loader = new FXMLLoader(...)`: El `FXMLLoader` no solo carga el FXML, sino que también gestiona el proceso.
 * - `ModificacionGastoController controller = loader.getController();`: Después de `loader.load()`, podemos solicitar
 * al `loader` una referencia al controlador de la pantalla que acabamos de cargar.
 * - `controller.initData(gasto);`: Se invoca un método público en el controlador de destino (`ModificacionGastoController`)
 * para pasarle el objeto `Gasto` seleccionado. Esto es una forma de inyección de dependencias manual que "prepara"
 * a la nueva pantalla con el contexto necesario antes de que sea mostrada al usuario.
 * - El resto del método implementa el cambio de escena estándar en el `Stage` actual.
 * =================================================================================================
 */