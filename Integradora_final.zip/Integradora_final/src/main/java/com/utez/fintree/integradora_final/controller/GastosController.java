package com.utez.fintree.integradora_final.controller;

import com.utez.fintree.integradora_final.GestorDatos;
import com.utez.fintree.integradora_final.model.Gasto;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.IOException;

public class GastosController extends BaseController {

    @FXML private ImageView walletIconTop;
    @FXML private BarChart<String, Number> chartGastos1;
    @FXML private ListView<Gasto> listaGastos;

    @FXML
    public void initialize() {
        try {
            walletIconTop.setImage(new Image(getClass().getResourceAsStream("/icons/wallet_icon.png")));
        } catch (Exception e) { System.err.println("Error al cargar icono."); }

        listaGastos.setItems(GestorDatos.getInstance().getGastos());
        listaGastos.setCellFactory(param -> new ListCell<>() {
            private final HBox hbox = new HBox(10);
            private final Text text = new Text();
            private final Pane pane = new Pane();
            private final Button button = new Button("Editar");

            {
                hbox.getChildren().addAll(text, pane, button);
                HBox.setHgrow(pane, Priority.ALWAYS);
                button.setOnAction(event -> {
                    Gasto item = getItem();
                    if (item != null) abrirPantallaDeEdicion(item, event);
                });
            }
            @Override
            protected void updateItem(Gasto item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) setGraphic(null);
                else {
                    text.setText(String.format("[%s] %s - $%.2f", item.getCategoria(), item.getConcepto(), item.getMonto()));
                    setGraphic(hbox);
                }
            }
        });
    }

    private void abrirPantallaDeEdicion(Gasto gasto, ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/utez/fintree/integradora_final/ModificacionGastoView.fxml"));
            Parent root = loader.load();
            ModificacionGastoController controller = loader.getController();
            controller.initData(gasto);
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML
    void handleRegistrarGasto(ActionEvent event) {
        navegarA("RegistroGastoView.fxml", event);
    }
}